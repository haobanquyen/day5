# Quadratic-Equation-Solver
<hr>

## Here are some screen shots

<p align="center">
  <img src="public/img/result1.png" title="result">
  <br>
  <img src="public/img/result2.png" title="result">
  <br>
  <img src="public/img/result3.png" title="result">
  <br>
  <img src="public/img/result4.png" title="result">
</p>

<hr>

 <hr>

 ## Cloning this repositary
 1. Open **Git Bash**.
 1. Change the current working directory to the location where you want the cloned directory.
 1. Type `git clone git@github.com:iris-mygh/GiaiPhuongTrinhBac2.git`
 1. Press **Enter** to create the clone of this repositary.

 <hr>

