nine=()=>{
    document.getElementById("display").value+='9';
}

eight=()=>{
    document.getElementById("display").value+='8';
}

seven=()=>{
    document.getElementById("display").value+='7';
}

six=()=>{
    document.getElementById("display").value+='6';
}

five=()=>{
    document.getElementById("display").value+='5';
}

four=()=>{
    document.getElementById("display").value+='4';
}

three=()=>{
    document.getElementById("display").value+='3';
}

two=()=>{
    document.getElementById("display").value+='2';
}

one=()=>{
    document.getElementById("display").value+='1';
}

zero=()=>{
    document.getElementById("display").value+='0';
}

add=()=>{
    document.getElementById("display").value+='+';
}

sub=()=>{
    document.getElementById("display").value+='-';
}

divi=()=>{
    document.getElementById("display").value+='/';
}

multi=()=>{
    document.getElementById("display").value+='*';
}

ans=()=>{
    document.getElementById("display").value=eval(document.getElementById("display").value);
}

dot=()=>{
    document.getElementById("display").value+='.';
}
